12/22/2021: Updated version 1.0.6
	- Updated YITH WooCommerce Product Gallery & Image Zoom
	
07/14/2021: Updated version 1.0.5
	- Updated Roadtheme Import Data
	- Fix bug Roadtheme-helper plugin

03/18/2021: Updated version 1.0.4
	- Updated Woocommerce version 5.1.x
	- Updated YITH WooCommerce Zoom Magnifier version 1.3.23
	
08/19/2020: Updated version 1.0.3
	- Updated theme compatible with WordPress 5.5

02/17/2019: Updated version 1.0.2
	- Changed link download require plugins
	- Updated woocommerce v_3.9.2
	- Fixed bug product categories widget
	
12/02/2019: Updated version 1.0.1
	- Updated WooCommerce 3.8.0 